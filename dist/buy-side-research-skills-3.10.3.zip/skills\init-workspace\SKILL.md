---
name: init-workspace
description: Initialize or repair a buy-side research workspace root scaffold and helper scripts.
---

# Init Workspace

`init-workspace` turns a normal folder into a usable buy-side research workspace. It creates or repairs the root scaffold, writes workspace `CLAUDE.md`, `AGENTS.md`, `.gitignore`, and `edge-radar.md`, and copies ingest / financial-data helper scripts into `_scripts/`.

It is an operations skill, not a research skill. It does not research companies, ingest files, install dependencies, run `git init`, create topic artifacts, or create topic-level `_raw/`, `_cache/`, or `_models/` directories.

## Mental Model

The invariant is separation of concerns:

- `init-workspace` creates the root workspace shell.
- `new-session` creates or locates a topic root with `index.md` and `_inbox/`.
- `ingest` creates `_raw/<category>/` and `_cache/` only when material is converted.
- `financial-data`, `driver-map`, and modeling skills create their own cache/model folders when they run.

The default behavior must be conservative, idempotent, and repeatable. Existing core files are skipped, not overwritten.

## Responsibilities

Responsible for:

- Creating root `_inbox/`, `_scripts/`, and `topics/`.
- Writing missing root `CLAUDE.md`, `AGENTS.md`, `.gitignore`, and `edge-radar.md`.
- Copying init assets, ingest scripts, ingest requirements, and ingest dependency bootstrap into `_scripts/`.
- Copying financial-data scripts, providers, requirements, and dependency bootstrap into `_scripts/financial-data/`.

Not responsible for:

- Ingesting PDF / Excel / PPTX / DOCX materials.
- Installing Docling, EdgarTools, Tesseract, MarkItDown, or Python packages.
- Creating dated topic research artifacts.
- Creating topic roots; use `new-session`.
- Creating topic-level `_raw/`, `_cache/`, or `_models/`.
- Running `git init`.
- Initializing inside the plugin dev repo or plugin install directory.

## Trigger And Input

Trigger phrases:

- "init research workspace"
- "初始化研究工作区"
- "创建研究文件夹"
- "setup research"
- "bootstrap workspace"
- "补齐 research workspace"

Required input:

- `WorkspacePath`: an explicit user-owned research workspace path.
- The target path must not be the plugin repo, a plugin install directory, or any folder containing plugin markers such as `.claude-plugin/`, `.codex-plugin/`, or `skills/`.
- Existing `CLAUDE.md`, `AGENTS.md`, `.gitignore`, and root `edge-radar.md` must be skipped, not overwritten.

## Modes

### New Workspace Scaffold

When the target path does not exist or is empty, create the root scaffold, root templates, and `_scripts/` helper files.

### Repair Existing Workspace

When the target path already has content, only add missing root scaffold directories and missing core files. Do not repair topic-level `_raw/`, `_cache/`, or `_models/`; those are owned by downstream skills.

### Dry Explanation

When the user only asks what init will do or what the folder will look like, do not run the helper script. Explain the root scaffold and boundaries.

## Tool Resources

Use the helper script when mutating files:

- `skills/init-workspace/scripts/init-research-workspace.ps1`

Runtime assets copied by the helper:

- `skills/init-workspace/assets/CLAUDE.md.template`
- `skills/init-workspace/assets/AGENTS.md.template`
- `skills/init-workspace/assets/gitignore.template`
- `skills/init-workspace/assets/edge-radar.md`
- `skills/init-workspace/assets/env-setup.ps1.template`
- `skills/ingest/scripts/ingest.py`
- `skills/ingest/scripts/ingest_xlsx.py`
- `skills/ingest/scripts/ingest_table_crosscheck.py`
- `skills/ingest/scripts/bootstrap-ingest-deps.ps1`
- `skills/ingest/assets/requirements-ingest.txt`
- `skills/financial-data/scripts/financial_data.py`
- `skills/financial-data/scripts/bootstrap-financial-data-deps.ps1`
- `skills/financial-data/scripts/providers/*.py`
- `skills/financial-data/assets/requirements-financial-data.txt`

Prefer the helper script over hand-written copy logic.

## File Safety

- Idempotent: reruns only add missing items.
- Never overwrite existing `CLAUDE.md`, `AGENTS.md`, `.gitignore`, or `edge-radar.md`.
- Never delete or move user files.
- Never initialize inside a plugin repo, plugin install directory, or any directory containing plugin manifests.
- Never treat `_raw/`, `_cache/`, `_models/`, or `_inbox/` as publishable research outputs.

## Output Contract

After success or repair:

```markdown
## Init Result

**结论先行**
已初始化 / 已补齐 research workspace：[path]

## Created
- [...]

## Skipped
- [...]

## Workspace Shape
[root scaffold tree]
```

When blocked:

```markdown
## Init Blocked

**结论先行**
不能在这个路径初始化 research workspace。
- path: [...]
- reason: [...]
- suggested_path: [...]
```

## Failure Handling

- Missing path: ask for an explicit `WorkspacePath`; do not guess.
- Plugin repo markers found: refuse and ask for a user-owned research workspace.
- Permission failure: name the exact path that failed; do not pretend success.
- Missing helper script: report that the plugin package is incomplete and ask the user to reinstall or repair the release package.

## Workflow Links

| Scenario | Handling |
|---|---|
| User just installed the plugin and does not know where to start | Use `init-workspace` to create the root workspace scaffold |
| Existing workspace is missing root scaffold files | Use `init-workspace` repair |
| User wants to start a company / industry / theme / pair topic | Hand off to `new-session` |
| User drops materials into a topic `_inbox/` | Hand off to `ingest` |
| User needs structured financial data | Hand off to `financial-data` |
| User needs to promote company workbench files from an industry/theme topic | Hand off to `promote-company` |
| User wants to merge whole topic directories | Hand off to `integrate` |
| User lacks ingest dependencies | Suggest `_scripts/bootstrap-ingest-deps.ps1 -CheckOnly`; run `-Yes` only after explicit opt-in |
| User lacks financial-data dependencies | Suggest `_scripts/financial-data/bootstrap-financial-data-deps.ps1 -CheckOnly`; run `-Yes` only after explicit opt-in |

Artifact policy:

- `save_policy`: `workspace_scaffold`
- `default_artifact`: `workspace scaffold`
- `canonical_location`: user-provided research workspace

## Safety Self-Check

- Did not initialize inside the plugin repo.
- Did not overwrite existing root files.
- Did not run `git init`.
- Did not ingest raw materials.
- Did not fetch financial data.
- Did not install dependencies.
- Did not create topic artifacts.
- Did not create topic-level `_raw/`, `_cache/`, or `_models/`.
- Did not recreate v2 state folders such as `coverage/`, `portfolio/`, or `pairs/`.
